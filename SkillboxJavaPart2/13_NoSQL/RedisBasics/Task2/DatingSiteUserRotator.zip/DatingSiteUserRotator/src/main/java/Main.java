import java.util.ArrayList;
import java.util.Random;

public class Main {

    // Зарегистрировалось
    private static final int USERS = 20;

    // Задержка для регистрации
    private static final int REGISTER_SLEEP = 20;

    // Задержка для показа
    private static final int SLEEP = 1000;

    public static void main(String[] args) throws Exception {

        RedisStorage redis = new RedisStorage();
        redis.init();

        // Эмулируем работу сайта:
        // регистрируем пользователей
        for (int i = 0; i < USERS; i++) {
            redis.registerUser(i); // регистрируем пользователя, задавая каждому score в зависимости от времени
            Thread.sleep(REGISTER_SLEEP);
        }

        // Бесконечный цикл перебора юзеров
        for (; ; ) {

            // Получаем очередь из базы данных
            ArrayList<String[]> userLine = redis.getUserLine();
            // Получаем случайных юзеров, которые оплатят внеочередной подъем и помещаем их в лист
            ArrayList<Integer> paidUsersId = new ArrayList<>();
            for (int j = 0; j < userLine.size(); j++) {
                if (Math.random() <= 0.1) {
                    paidUsersId.add(Integer.parseInt(userLine.get(j)[1]));
                }
            }

            // Для каждого определим момент, в который он оплачивает (перед каким случайным юзером наступит его очередь)
            ArrayList<Integer> waitUsers = new ArrayList<>(); // наполняем столько же, сколько внеочередников
            for (int userId : paidUsersId) {  // также номер того, кого "подвинут" должен быть меньше, чем внеочередника
                for (; ; ) {
                    int tempRandom = new Random().nextInt(USERS);
                    if (!paidUsersId.contains(tempRandom) && tempRandom < userId) {
                        waitUsers.add(tempRandom);
                        break;
                    }
                }
            }

            // Предыдущие рейтинг и Id пользователей записываем в отдельный лист
            ArrayList<String[]> oldValues = new ArrayList<>();
            // меняем приоритеты показа (очередь), изменяя рейтинг пользователей
            for (int k = 0; k < paidUsersId.size(); k++) {
                // Требуемое значение рейтинга
                int currentId = paidUsersId.get(k);
                Double currentPaidUserScore = redis.getUserScoreById(String.valueOf(currentId));
                Double newPaidUserScore;
                Double currentUserInLineScore = redis.getUserScoreById(String.valueOf(waitUsers.get(k)));
                if (waitUsers.get(k) >= 1) {
                    Double previousUserInLineScore = redis.getUserScoreById(String.valueOf(waitUsers.get(k) - 1));
                    newPaidUserScore = 0.5 * currentUserInLineScore + 0.5 * previousUserInLineScore;
                }
                else
                    { // Это самое первое число, значит уменьшим новому значению рейтинг, чтобы его подвинуть
                    newPaidUserScore = currentUserInLineScore - 1.0;
                }
                String[] oldData = {String.valueOf(currentPaidUserScore), String.valueOf(currentId)};
                oldValues.add(oldData);
                // устанавливаем полученный рейтинг
                redis.changeUserScore(currentPaidUserScore, newPaidUserScore, String.valueOf(paidUsersId.get(k)));
            }
            // Получаем заново сформированную очередь и выводим ее
            ArrayList<String[]> showUserLine = redis.getUserLine();
            for (int i = 0; i < showUserLine.size(); i++) {
                System.out.println("Показываем пользователя с рейтингом " + showUserLine.get(i)[0] + " и ID: " + showUserLine.get(i)[1]);
                Thread.sleep(SLEEP);
            }

            // Возвращаем рейтинги обратно
            for (int m = 0; m < oldValues.size(); m++) {
                Double currentNewUserScore = redis.getUserScoreById(String.valueOf(oldValues.get(m)[1]));
                redis.changeUserScore(currentNewUserScore, Double.parseDouble(oldValues.get(m)[0]), oldValues.get(m)[1]);
                Thread.sleep(REGISTER_SLEEP);
            }

            System.out.println("===================================");
        }
    }
}